package com.company;
import java.util.Scanner;
import java.lang.*;

public class Main {

    public static void main(String[] args) {
        //1
        System.out.println("Enter your name : ");
        Scanner scan  = new Scanner(System.in);
        String name = scan.nextLine();
        //2
        System.out.println("Enter your age : ");
        Scanner scanner  = new Scanner(System.in);
        int age = scanner.nextInt();
        //3
        System.out.println("Enter temperature : ");
        Scanner scanner1  = new Scanner(System.in);
        int temperature = scanner1.nextInt();
        //4
        /*if (temperature>30 || temperature<20){
            System.out.println("Stay home.");
        }else {
            System.out.println("You can go to your friend!");
        }*/
        //5
        /*if(age<20){
            temperature= (int) (0+Math.random()*29);
            System.out.println("Now temperature is : "+temperature);
            if (temperature>30 || temperature<20){
                System.out.println("Stay home.");
            }else {
                System.out.println("You can go to your friend!");
            }

        }else if(age>=45){
            temperature= (int) (-10+Math.random()*26);
            System.out.println("Now temperature is : "+temperature);
            if (temperature>30 || temperature<20){
                System.out.println("Stay home.");
            }else {
                System.out.println("You can go to your friend!");
            }



        }*/
        generateRandomAge();
        //7
        int newRandomAge = (int) (Math.random()*108);
        System.out.println("Your new random age : "+newRandomAge);
    }
        //6
        public static void generateRandomAge(){
            int randomAge = (int) (Math.random()*100);
            System.out.println("Your random age : "+randomAge);
        }


}
